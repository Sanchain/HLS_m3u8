//
//  VideoDownloader.m
//  XB
//
//  Created by luoxubin on 3/8/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "VideoDownloader.h"
#import "AFNetworking.h"


@implementation VideoDownloader
@synthesize playlist;


- (id)initWithM3U8List:(M3U8Playlist *)list
{
    self = [super init];
    if(self)
    {
        self.playlist = list;
    }
    return  self;
}


-(void)startDownloadVideo
{
    NSLog(@"-- m3u8索引的TS分片总数量 ：%ld --", (long)self.playlist.length); // self.playlist.length 表示的视频片段的总数

    if (self.playlist) {
        playlist = self.playlist;
    }

    NSInteger firstTS = arc4random_uniform((u_int32_t)self.playlist.length);
    NSLog(@"-- 开始下载第%ld个TS分片 --", firstTS);

    for(int i = 0; i < self.playlist.length; i++)
    {
        if (i == firstTS) { // 可以实现 下载随机TS文件
            M3U8SegmentInfo *segment = [self.playlist getSegment:i];
            [self downloadMPEGTSFileRequestWithTsURL:segment.locationUrl];
        }
    }
}


// 下载ts文件
- (void)downloadMPEGTSFileRequestWithTsURL:(NSString *)tsURL {
    
    AFHTTPSessionManager *manger = [AFHTTPSessionManager manager];
    NSURLRequest *request = [NSURLRequest requestWithURL:[NSURL URLWithString:tsURL]];
    [[manger downloadTaskWithRequest:request progress:NULL destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
//        NSLog(@"-- 缩略后缀 -- %@", response.suggestedFilename); // 80.ts
        // 下载路径最好以设备ID作为TS文件名标识
        NSString *filePath = [NSTemporaryDirectory() stringByAppendingPathComponent:response.suggestedFilename];
        NSURL *url = [NSURL fileURLWithPath:filePath];
        return url;
        
    } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
        NSString *tsFilePath = [[filePath absoluteString] stringByReplacingOccurrencesOfString:@"file://" withString:@""];
        NSLog(@"-- 下载TS分片成功 文件路径 -- %@,", tsFilePath);
        if ([self.delegate respondsToSelector:@selector(videoDownloaderFinishedWithTSPath:)]) {
            [self.delegate videoDownloaderFinishedWithTSPath:tsFilePath];
        }
    }] resume];
}


@end
