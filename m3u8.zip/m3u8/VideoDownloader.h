//
//  VideoDownloader.h
//  XB
//
//  Created by luoxubin on 3/8/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "M3U8Playlist.h"


@protocol VideoDownloaderDelegate <NSObject>
- (void)videoDownloaderFinishedWithTSPath:(NSString *)tsPath; /*! 完成TS分片的下载 */
@end

@interface VideoDownloader : NSObject
{
    M3U8Playlist *playlist;
}
@property(nonatomic, retain) id<VideoDownloaderDelegate> delegate;
@property(nonatomic, retain)M3U8Playlist *playlist;

-(id)initWithM3U8List:(M3U8Playlist*)list;

//开始下载
-(void)startDownloadVideo;

@end
